from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login as auth_login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import Http404
from .models import Expense, Bill, Reminder, Task, ShoppingItem, FitnessProfile, WorkoutPlan, DietPlan, FitnessGoal,Note
from datetime import datetime
from django.db.models import Q
from django.contrib.auth.forms import UserCreationForm
from .models import User
from functools import wraps
from django.contrib.auth.models import User
from .models import ChatMessage
import ollama

# Existing views (like home, todo_list, etc.) remain unchanged
def home(request):
    return render(request, 'task_management/home.html')

def contact_us(request):
    return render(request, 'task_management/contact_us.html')

@login_required
def calendar_view(request):
    token = get_graph_token(request)
    if not token:
        messages.error(request, "Please connect your Microsoft Calendar first.")
        return redirect('microsoft_login')

    # Fetch calendar events
    headers = {
        'Authorization': f'Bearer {token}',
        'Content-Type': 'application/json'
    }
    response = requests.get(
        f"{settings.MICROSOFT_GRAPH['ENDPOINT']}/me/events?$top=10",
        headers=headers
    )

    events = []
    if response.status_code == 200:
        events = response.json().get('value', [])
    else:
        messages.error(request, "Failed to fetch calendar events.")

    return render(request, 'task_management/calendar.html', {'events': events})

# Add other views as needed

def login_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.session.get('user_id'):
            return redirect('login')
        return view_func(request, *args, **kwargs)
    return wrapper

def signup(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        password = request.POST.get('password')
        confirm_password = request.POST.get('confirm_password')

        # Validation
        if password != confirm_password:
            return render(request, 'signup.html', {'error': 'Passwords do not match.'})
        
        if User.objects.filter(username=username).exists():
            return render(request, 'signup.html', {'error': 'Username already exists.'})
        
        if User.objects.filter(email=email).exists():
            return render(request, 'signup.html', {'error': 'Email already exists.'})

        # Create new user
        user = User(username=username, email=email)
        user.set_password(password)
        user.save()

        # Log the user in by setting session
        request.session['user_id'] = user.id
        return redirect('notes')
    return render(request, 'task_management/signup.html')

def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        try:
            user = User.objects.get(username=username)
            if user.check_password(password):
                # Log the user in by setting session
                request.session['user_id'] = user.id
                return redirect('notes')
            else:
                return render(request, 'login.html', {'error': 'Invalid password.'})
        except User.DoesNotExist:
            return render(request, 'login.html', {'error': 'Username does not exist.'})
    return render(request, 'login.html')

def logout(request):
    # Clear the session
    request.session.flush()
    return redirect('login')

def home(request):
    return render(request, 'task_management/home.html')

def expense_tracking(request):
    expenses = Expense.objects.all()
    return render(request, 'task_management/expense_tracking.html', {'expenses': expenses})

def bill_payment_alerts(request):
    upcoming_bills = Bill.objects.filter(status='Pending')
    paid_bills = Bill.objects.exclude(status='Pending')
    return render(request, 'task_management/bill_payment_alerts.html', {
        'upcoming_bills': upcoming_bills,
        'paid_bills': paid_bills
    })

def reminders(request):
    upcoming_reminders = Reminder.objects.filter(completed=False)
    completed_reminders = Reminder.objects.filter(completed=True)
    return render(request, 'task_management/reminders.html', {
        'upcoming_reminders': upcoming_reminders,
        'completed_reminders': completed_reminders})

def todo_list(request):
    user = None
    user_id = request.session.get('user_id')
    if user_id:
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            messages.error(request, 'User not found. Please log in again.')
            request.session.flush()
            return redirect('login')

    search = request.GET.get('search', '')
    filter_status = request.GET.get('filter_status', 'all')
    filter_category = request.GET.get('filter_category', '')
    filter_due_date = request.GET.get('filter_due_date', '')
    sort = request.GET.get('sort', '')
    editing_task_id = request.GET.get('editing_task_id', '')

    if user:
        tasks = Task.objects.filter(user=user)
    else:
        tasks = Task.objects.filter(user__isnull=True)

    if search:
        tasks = tasks.filter(
            Q(title__icontains=search) |
            Q(category__icontains=search) |
            Q(priority__icontains=search)
        )

    if filter_status == 'completed':
        tasks = tasks.filter(completed=True)
    elif filter_status == 'not-completed':
        tasks = tasks.filter(completed=False)

    if filter_category:
        tasks = tasks.filter(category=filter_category)

    if filter_due_date:
        try:
            tasks = tasks.filter(due_date=filter_due_date)
        except ValueError:
            messages.error(request, 'Invalid due date format.')

    if sort == 'name':
        tasks = tasks.order_by('title')
    elif sort == 'due-date':
        tasks = tasks.order_by('due_date')
    elif sort == 'priority':
        tasks = tasks.order_by('-priority')

    tasks_list = [{
        'id': task.id,
        'title': task.title,
        'due_date': task.due_date,
        'priority': task.priority,
        'category': task.category,
        'completed': task.completed,
        'is_editing': str(task.id) == editing_task_id
    } for task in tasks]

    if request.method == 'POST':
        action = request.POST.get('action')
        task_id = request.POST.get('task_id')

        if action == 'add':
            title = request.POST.get('title')
            due_date = request.POST.get('due_date')
            priority = request.POST.get('priority')
            category = request.POST.get('category')

            if title and priority and category:
                task = Task(
                    user=user,
                    title=title,
                    due_date=due_date if due_date else None,
                    priority=priority,
                    category=category
                )
                task.save()
                messages.success(request, 'Task added successfully!')
            else:
                messages.error(request, 'Title, priority, and category are required.')
            return redirect('todo_list')

        elif action == 'complete' and task_id:
            try:
                task = Task.objects.get(id=task_id, user=user if user else None)
                if not task.completed:
                    task.completed = True
                    task.save()
                    messages.success(request, 'Task Completed')
                else:
                    messages.info(request, 'Task is already completed.')
            except Task.DoesNotExist:
                messages.error(request, 'Task not found.')
            return redirect('todo_list')

        elif action == 'modify' and task_id:
            try:
                Task.objects.get(id=task_id, user=user if user else None)
                return redirect(f'/todo-list/?editing_task_id={task_id}')
            except Task.DoesNotExist:
                messages.error(request, 'Task not found.')
            return redirect('todo_list')

        elif action == 'save' and task_id:
            title = request.POST.get('title')
            due_date = request.POST.get('due_date')
            priority = request.POST.get('priority')
            category = request.POST.get('category')

            try:
                task = Task.objects.get(id=task_id, user=user if user else None)
                if title and priority and category:
                    task.title = title
                    task.due_date = due_date if due_date else None
                    task.priority = priority
                    task.category = category
                    task.save()
                    messages.success(request, 'Task updated successfully!')
                else:
                    messages.error(request, 'Title, priority, and category are required.')
            except Task.DoesNotExist:
                messages.error(request, 'Task not found.')
            return redirect('todo_list')

        elif action == 'cancel' and task_id:
            return redirect('todo_list')

        elif action == 'delete' and task_id:
            try:
                task = Task.objects.get(id=task_id, user=user if user else None)
                task.delete()
                messages.success(request, 'Task deleted successfully!')
            except Task.DoesNotExist:
                messages.error(request, 'Task not found.')
            return redirect('todo_list')

    context = {
        'tasks': tasks_list,
        'search': search,
        'filter_status': filter_status,
        'filter_category': filter_category,
        'filter_due_date': filter_due_date,
        'sort': sort,
        'editing_task_id': editing_task_id
    }
    return render(request, 'task_management/todo_list.html', context)


def shopping_list(request):
    # Handle multiple shopping lists
    selected_list = request.GET.get('list_name', '')
    shopping_lists = ShoppingItem.objects.values_list('list_name', flat=True).distinct()
    if not selected_list and shopping_lists:
        selected_list = shopping_lists[0]  # Default to the first list

    # Filter items by selected list
    items = ShoppingItem.objects.filter(list_name=selected_list) if selected_list else ShoppingItem.objects.all()

    # Sorting
    sort = request.GET.get('sort', '')
    if sort == 'name':
        items = items.order_by('name')
    elif sort == 'category':
        items = items.order_by('category')

    # Filtering
    filter_status = request.GET.get('filter_status', '')
    if filter_status == 'bought':
        items = items.filter(purchased=True)
    elif filter_status == 'unbought':
        items = items.filter(purchased=False)

    filter_category = request.GET.get('filter_category', '')
    if filter_category:
        items = items.filter(category=filter_category)

    # Prepare items for rendering
    items_list = [{
        'id': item.id,
        'name': item.name,
        'quantity': item.quantity,
        'category': item.category,
        'notes': item.notes,
        'purchased': item.purchased,
        'is_editing': False
    } for item in items]

    if request.method == 'POST':
        action = request.POST.get('action')
        item_id = request.POST.get('item_id')

        if action == 'save_list':
            new_list_name = request.POST.get('new_list_name')
            if new_list_name:
                # Copy current items to the new list
                current_items = ShoppingItem.objects.filter(list_name=selected_list) if selected_list else ShoppingItem.objects.all()
                for item in current_items:
                    ShoppingItem.objects.create(
                        list_name=new_list_name,
                        name=item.name,
                        quantity=item.quantity,
                        category=item.category,
                        notes=item.notes,
                        purchased=item.purchased
                    )
                messages.success(request, f'Shopping list "{new_list_name}" saved successfully!')
                return redirect(f'shopping_list?list_name={new_list_name}')
            else:
                messages.error(request, 'List name cannot be empty.')
            return redirect('shopping_list')

        if action == 'add':
            item_name = request.POST.get('item_name')
            quantity = request.POST.get('quantity')
            category = request.POST.get('category')
            notes = request.POST.get('notes')
            if item_name and quantity and category:
                item = ShoppingItem(
                    list_name=selected_list,
                    name=item_name,
                    quantity=int(quantity),
                    category=category,
                    notes=notes
                )
                item.save()
                messages.success(request, 'Item added successfully!')
            else:
                messages.error(request, 'Item name, quantity, and category are required.')
            return redirect(f'shopping_list?list_name={selected_list}' if selected_list else 'shopping_list')

        elif action == 'toggle' and item_id:
            try:
                item = ShoppingItem.objects.get(id=item_id)
                item.purchased = not item.purchased
                item.save()
                messages.success(request, 'Item updated successfully!')
            except ShoppingItem.DoesNotExist:
                messages.error(request, 'Item not found.')
            return redirect(f'shopping_list?list_name={selected_list}' if selected_list else 'shopping_list')

        elif action == 'edit' and item_id:
            try:
                ShoppingItem.objects.get(id=item_id)
                for item in items_list:
                    if str(item['id']) == item_id:
                        item['is_editing'] = True
                return render(request, 'task_management/shopping_list.html', {
                    'items': items_list,
                    'shopping_lists': shopping_lists,
                    'selected_list': selected_list,
                    'sort': sort,
                    'filter_status': filter_status,
                    'filter_category': filter_category
                })
            except ShoppingItem.DoesNotExist:
                messages.error(request, 'Item not found.')
            return redirect(f'shopping_list?list_name={selected_list}' if selected_list else 'shopping_list')

        elif action == 'save' and item_id:
            try:
                item_name = request.POST.get('item_name')
                quantity = request.POST.get('quantity')
                category = request.POST.get('category')
                notes = request.POST.get('notes')
                if item_name and quantity and category:
                    item = ShoppingItem.objects.get(id=item_id)
                    item.name = item_name
                    item.quantity = int(quantity)
                    item.category = category
                    item.notes = notes
                    item.save()
                    messages.success(request, 'Item updated successfully!')
                else:
                    messages.error(request, 'Item name, quantity, and category are required.')
            except ShoppingItem.DoesNotExist:
                messages.error(request, 'Item not found.')
            return redirect(f'shopping_list?list_name={selected_list}' if selected_list else 'shopping_list')

        elif action == 'cancel' and item_id:
            return redirect(f'shopping_list?list_name={selected_list}' if selected_list else 'shopping_list')

        elif action == 'delete' and item_id:
            try:
                item = ShoppingItem.objects.get(id=item_id)
                item.delete()
                messages.success(request, 'Item deleted successfully!')
            except ShoppingItem.DoesNotExist:
                messages.error(request, 'Item not found.')
            return redirect(f'shopping_list?list_name={selected_list}' if selected_list else 'shopping_list')

    return render(request, 'task_management/shopping_list.html', {
        'items': items_list,
        'shopping_lists': shopping_lists,
        'selected_list': selected_list,
        'sort': sort,
        'filter_status': filter_status,
        'filter_category': filter_category
    })

def fitness_health(request):
    fitness_profile = FitnessProfile.objects.first()
    if not fitness_health:
        fitness_profile = FitnessProfile.objects.create()

    workout_plans = WorkoutPlan.objects.all()
    pre_designed_workouts = WorkoutPlan.objects.filter(is_pre_designed=True)
    diet_plans = DietPlan.objects.all()
    pre_designed_diets = DietPlan.objects.filter(is_pre_designed=True)
    fitness_goals = FitnessGoal.objects.all()

    if request.method == 'POST':
        action = request.POST.get('action')

        if action == 'update_profile':
            age = request.POST.get('age')
            weight = request.POST.get('weight')
            height = request.POST.get('height')
            gender = request.POST.get('gender')
            fitness_goal = request.POST.get('fitness_goal')
            health_issues = request.POST.get('health_issues')

            fitness_profile.age = age
            fitness_profile.weight = weight
            fitness_profile.height = height
            fitness_profile.gender = gender
            fitness_profile.fitness_goal = fitness_goal
            fitness_profile.health_issues = health_issues
            fitness_profile.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('fitness_health')

        elif action == 'add_workout':
            workout_name = request.POST.get('workout_name')
            workout_description = request.POST.get('workout_description')
            workout_duration = request.POST.get('workout_duration')
            workout_calories = request.POST.get('workout_calories')

            if workout_name and workout_description and workout_duration and workout_calories:
                workout_plan = WorkoutPlan(
                    name=workout_name,
                    description=workout_description,
                    duration=workout_duration,
                    calories_burned=workout_calories
                )
                workout_plan.save()
                messages.success(request, 'Workout plan added successfully!')
            else:
                messages.error(request, 'All fields are required.')
            return redirect('fitness_health')

        elif action == 'add_diet':
            diet_name = request.POST.get('diet_name')
            diet_description = request.POST.get('diet_description')
            diet_calories = request.POST.get('diet_calories')

            if diet_name and diet_description and diet_calories:
                diet_plan = DietPlan(
                    name=diet_name,
                    description=diet_description,
                    total_calories=diet_calories
                )
                diet_plan.save()
                messages.success(request, 'Diet plan added successfully!')
            else:
                messages.error(request, 'All fields are required.')
            return redirect('fitness_health')

        elif action == 'set_goal':
            goal_type = request.POST.get('goal_type')
            target_value = request.POST.get('target_value')
            end_date = request.POST.get('end_date')

            if goal_type and target_value and end_date:
                fitness_goal = FitnessGoal(
                    goal_type=goal_type,
                    target_value=target_value,
                    end_date=datetime.strptime(end_date, '%Y-%m-%d')
                )
                fitness_goal.save()
                messages.success(request, 'Goal set successfully!')
            else:
                messages.error(request, 'All fields are required.')
            return redirect('fitness_health')

    context = {
        'fitness_profile': fitness_profile,
        'workout_plans': workout_plans,
        'pre_designed_workouts': pre_designed_workouts,
        'diet_plans': diet_plans,
        'pre_designed_diets': pre_designed_diets,
        'fitness_goals': fitness_goals
    }
    return render(request, 'task_management/fitness_health.html', context)

def note_taking(request):
    # Get the user from session, if available
    user = None
    user_id = request.session.get('user_id')
    if user_id:
        try:
            user = User.objects.get(id=user_id)
        except User.DoesNotExist:
            messages.error(request, 'User not found. Please log in again.')
            request.session.flush()  # Clear invalid session
            return redirect('login')

    # Get filter and sort parameters
    search = request.GET.get('search', '')
    sort = request.GET.get('sort', '')
    
    # Get editing note ID if any
    editing_note_id = request.GET.get('editing_note_id', '')

    # Filter notes by user (or no user if anonymous)
    if user:
        notes = Note.objects.filter(user=user)
    else:
        notes = Note.objects.filter(user__isnull=True)  # Show notes not tied to any user for anonymous access

    # Apply search filter
    if search:
        notes = notes.filter(
            Q(title__icontains=search) |
            Q(content__icontains=search) |
            Q(tags__icontains=search)
        )

    # Apply sorting
    if sort == 'created':
        notes = notes.order_by('created_at')
    elif sort == 'edited':
        notes = notes.order_by('modified_at')
    elif sort == 'title':
        notes = notes.order_by('title')

    # Prepare notes list for rendering
    notes_list = [{
        'id': note.id,
        'title': note.title if note.title else "Untitled Note",
        'content': note.content,
        'category': note.tags if note.tags else "Other",  # Map tags to category for template
        'priority': note.priority,
        'created': note.created_at,
        'edited': note.modified_at,
        'is_editing': str(note.id) == editing_note_id
    } for note in notes]

    if request.method == 'POST':
        action = request.POST.get('action')
        note_id = request.POST.get('note_id')

        if action == 'add':
            title = request.POST.get('title')
            content = request.POST.get('content')
            category = request.POST.get('category')
            priority = request.POST.get('priority')

            if content and priority and category:
                note = Note(
                    user=user,  # Will be None for anonymous users
                    title=title,
                    content=content,
                    tags=category,  # Map category to tags
                    priority=priority
                )
                note.save()
                messages.success(request, 'Note added successfully!')
            else:
                messages.error(request, 'Content, priority, and category are required.')
            return redirect('note_taking')

        elif action == 'edit' and note_id:
            try:
                note = Note.objects.get(id=note_id, user=user if user else None)
                # Redirect with editing_note_id to show edit form
                return redirect(f'/note-taking/?editing_note_id={note_id}')
            except Note.DoesNotExist:
                messages.error(request, 'Note not found.')
            return redirect('note_taking')

        elif action == 'save' and note_id:
            title = request.POST.get('title')
            content = request.POST.get('content')
            category = request.POST.get('category')
            priority = request.POST.get('priority')

            try:
                note = Note.objects.get(id=note_id, user=user if user else None)
                if content and priority and category:
                    note.title = title
                    note.content = content
                    note.tags = category  # Map category to tags
                    note.priority = priority
                    note.save()
                    messages.success(request, 'Note updated successfully!')
                else:
                    messages.error(request, 'Content, priority, and category are required.')
            except Note.DoesNotExist:
                messages.error(request, 'Note not found.')
            return redirect('note_taking')

        elif action == 'cancel' and note_id:
            return redirect('note_taking')

        elif action == 'delete' and note_id:
            try:
                note = Note.objects.get(id=note_id, user=user if user else None)
                note.delete()
                messages.success(request, 'Note deleted successfully!')
            except Note.DoesNotExist:
                messages.error(request, 'Note not found.')
            return redirect('note_taking')

    context = {
        'notes': notes_list,
        'search': search,
        'sort': sort,
        'editing_note_id': editing_note_id
    }
    return render(request, 'task_management/note_taking.html', context)

def contact_us(request):
    return render(request, 'task_management/contact_us.html')
def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)
            messages.success(request, 'Registration successful! You are now logged in.')
            return redirect('home')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = UserCreationForm()
    return render(request, 'task_management/register.html', {'form': form})

def login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            auth_login(request, user)
            messages.success(request, 'Login successful!')
            return redirect('home')
        else:
            messages.error(request, 'Invalid username or password.')
    else:
        form = AuthenticationForm()
    return render(request, 'task_management/login.html', {'form': form})

# def logout(request):
#     auth_logout(request)
#     messages.success(request, 'You have been logged out.')
#     return redirect('home')

def custom_logout(request):
    logout(request)
    return redirect('home')


def contact_us(request):
    return render(request, 'task_management/contact_us.html')




def chat_with_elevate(request):
    # Get or create a session ID for the user
    session_id = request.session.session_key
    if not session_id:
        request.session.create()
        session_id = request.session.session_key

    # Fetch chat history for this session
    chat_history = ChatMessage.objects.filter(session_id=session_id).order_by('timestamp')

    if request.method == 'POST':
        user_message = request.POST.get('message', '').strip()
        if user_message:
            try:
                # Prepare the prompt with system message
                system_prompt = "You are ElevateBot, a helpful assistant for the Elevate app. You assist users with productivity, task management, and answering general questions."
                full_prompt = f"{system_prompt}\nUser: {user_message}\nAssistant:"

                print("Sending request to Ollama with prompt:", full_prompt)

                # Call Ollama directly using the library
                response = ollama.generate(
                    model='llama3.2:1b',
                    prompt=full_prompt,
                    options={
                        'temperature': 0.7,
                        'max_tokens': 150
                    }
                )

                print("Ollama response:", response)

                # Extract the bot response
                bot_response = response.get('response', '').strip()
                if not bot_response:
                    bot_response = "I didn't get a proper response. Please try again."
                    print("No response received from Ollama.")

                # Save the message and response to the database
                print("Saving to database:", user_message, bot_response)
                ChatMessage.objects.create(
                    user=None,
                    message=user_message,
                    response=bot_response,
                    session_id=session_id
                )

            except Exception as e:
                # Handle errors (e.g., server not running, model not found)
                error_message = f"Error: {str(e)}"
                print("Error occurred:", error_message)
                messages.error(request, error_message)
                return redirect('chat_with_elevate')

            # Redirect to the same page to refresh the chat history
            return redirect('chat_with_elevate')

    return render(request, 'task_management/chat_with_elevate.html', {
        'chat_history': chat_history
    })
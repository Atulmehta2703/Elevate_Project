from django.db import models
from django.contrib.auth.models import User

# Task Management
class Task(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    title = models.CharField(max_length=200)
    due_date = models.DateField(null=True, blank=True)
    priority = models.CharField(max_length=20, choices=[
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High')
    ], default='Low')
    category = models.CharField(max_length=50, choices=[
        ('Work', 'Work'),
        ('Personal', 'Personal'),
        ('Other', 'Other')
    ], default='Other')
    completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class ShoppingItem(models.Model):
    list_name = models.CharField(max_length=100, blank=True, null=True)  # To support multiple lists
    name = models.CharField(max_length=100)
    quantity = models.PositiveIntegerField(default=1)  # Added quantity field
    category = models.CharField(max_length=50)  # Added category field
    notes = models.TextField(blank=True, null=True)  # Added notes field
    purchased = models.BooleanField(default=False)

    def __str__(self):
        return self.name


# Finance
class Expense(models.Model):
    name = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    category = models.CharField(max_length=50, choices=[
        ('food', 'Food'),
        ('rent', 'Rent'),
        ('shopping', 'Shopping'),
        ('travel', 'Travel'),
        ('other', 'Other'),
    ])
    date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class Bill(models.Model):
    name = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    due_date = models.DateField()
    recurrence = models.CharField(max_length=20, choices=[
        ('one-time', 'One-time'),
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('yearly', 'Yearly'),
    ])
    payment_method = models.CharField(max_length=20, choices=[
        ('card', 'Card'),
        ('bank-transfer', 'Bank Transfer'),
        ('cash', 'Cash'),
    ])
    status = models.CharField(max_length=20, default='Pending')
    paid_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


# Reminders
class Reminder(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField(null=True, blank=True)
    date_time = models.DateTimeField()
    recurrence = models.CharField(max_length=20, choices=[
        ('one-time', 'One-time'),
        ('daily', 'Daily'),
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('yearly', 'Yearly'),
    ])
    priority = models.CharField(max_length=10, choices=[
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
    ])
    completed = models.BooleanField(default=False)
    completion_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


# Fitness
class FitnessProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
    age = models.IntegerField(null=True, blank=True)
    weight = models.FloatField(null=True, blank=True)  # in kg
    height = models.FloatField(null=True, blank=True)  # in cm
    gender = models.CharField(max_length=10, choices=[
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Other', 'Other')
    ], null=True, blank=True)
    fitness_goal = models.CharField(max_length=100, choices=[
        ('Weight Loss', 'Weight Loss'),
        ('Muscle Gain', 'Muscle Gain'),
        ('General Wellness', 'General Wellness')
    ], null=True, blank=True)
    health_issues = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username}'s Fitness Profile"


class WorkoutPlan(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=200)
    description = models.TextField()
    duration = models.IntegerField()  # in minutes
    calories_burned = models.FloatField(default=0.0)
    is_pre_designed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class DietPlan(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    name = models.CharField(max_length=200)
    description = models.TextField()
    total_calories = models.FloatField()
    is_pre_designed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class FitnessGoal(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    goal_type = models.CharField(max_length=100, choices=[
        ('Weight Loss', 'Weight Loss'),
        ('Muscle Gain', 'Muscle Gain'),
        ('Steps', 'Steps')
    ])
    target_value = models.FloatField()  # e.g., 5 kg for weight loss, 10000 for steps
    current_value = models.FloatField(default=0.0)
    start_date = models.DateField(auto_now_add=True)
    end_date = models.DateField()

    def __str__(self):
        return f"{self.goal_type} Goal for {self.user.username}"


# Notes
class Note(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)
    title = models.CharField(max_length=200, blank=True, null=True)
    content = models.TextField()
    tags = models.CharField(max_length=200, blank=True, null=True)  # Comma-separated tags
    priority = models.CharField(max_length=20, choices=[
        ('Low', 'Low'),
        ('Medium', 'Medium'),
        ('High', 'High')
    ], default='Low')
    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.title if self.title else "Untitled Note"

    def get_tags_list(self):
        if self.tags:
            return [tag.strip() for tag in self.tags.split(',')]
        return []

class ChatMessage(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)  # Made user optional
    message = models.TextField()
    response = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    session_id = models.CharField(max_length=100, null=True, blank=True)  # Added for session-based tracking

    def __str__(self):
        return f"{self.user.username if self.user else 'Anonymous'}: {self.message}"
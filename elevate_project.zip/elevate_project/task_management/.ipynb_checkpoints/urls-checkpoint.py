from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('expense-tracking/', views.expense_tracking, name='expense_tracking'),
    path('bill-payment-alerts/', views.bill_payment_alerts, name='bill_payment_alerts'),
    path('reminders/', views.reminders, name='reminders'),
    path('todo_list/', views.todo_list, name='todo_list'),
    path('shopping-list/', views.shopping_list, name='shopping_list'),
    path('fitness-health/', views.fitness_health, name='fitness_health'),
    path('note-taking/', views.note_taking, name='note_taking'),
    path('register/', views.register, name='register'),
    path('signup/', views.signup, name='signup'),
    path('login/', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
    path('contact-us/', views.contact_us, name='contact_us'),
    path('accounts/logout/', views.custom_logout, name='logout'),
    path('chat-with-elevate/', views.chat_with_elevate, name='chat_with_elevate'),
    
]